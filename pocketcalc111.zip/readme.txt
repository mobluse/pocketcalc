In Windows 95, use Wordpad to read this document.


Pocket Calculator emulates a pocket calculator of the simplest
kind. It was Mikael Bonnier's first Java program.

    Pocket Calculator v1.01 is Freeware
    Commercial Distribution Restricted
    Copyright (C) 1995-1996 by Mikael Bonnier, Lund, Sweden.


It was developed using JDK-1.0 on Windows 95.

Howto install Pocket Calculator on your web-page:
1. Save the class-files and a html-file with this tag:
      <APPLET CODE="PocketCalc.class" WIDTH="395" HEIGHT="179">
      <PARAM NAME="BGCOLOR" VALUE="#FF8000">
      </APPLET>
   in a file folder.
2. Open the html-file in a web-browser and you may try out all the
   features of the calculator.

See the source java-file for more info on how to compile.
There is an example html-file in this package.

Thanks are due to many people for reporting bugs and suggestions,
especially: Luis Fernandes, Bengt Ask, and Olivier Perrin.

Revision history:
1995-Dec: 1.0bX  Beta versions.
1996-Jan: 1.0    All keys implemented and an X Windows problem
                 fixed. 
1996-Jul: 1.01   Fixed bugs of unary operations after equals
                 operations.
1996-Nov: 1.1    Added parameter BGCOLOR. Added support to run
                 as an application.

Suggestions, improvements, and bug-reports
are always welcome to:
                 Mikael Bonnier
                 Osten Undens gata 88
                 SE-227 62  LUND
                 SWEDEN

Or use my internet addresses:
                 mikaelb@df.lth.se
                 http://www.df.lth.se/~mikaelb/
             _____
            /   / \
***********/   /   \***********
          /   /     \
*********/   /       \*********
        /   /   / \   \
*******/   /   /   \   \*******
      /   /   / \   \   \
*****/   /   /***\   \   \*****
    /   /__ /_____\   \   \
***/               \   \   \***
  /_________________\   \   \
**\                      \  /**
   \______________________\/

Mikael Bonnier
